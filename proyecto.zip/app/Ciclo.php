<?php

namespace colegioShaddai;

use Illuminate\Database\Eloquent\Model;

class Ciclo extends Model
{
    //
    protected $fillable =  ['nombre','estado'];
}
