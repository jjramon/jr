<?php

namespace colegioShaddai;

use Illuminate\Database\Eloquent\Model;

class Nivele extends Model
{
    //
    protected $fillable =  ['nombre','estado'];
}
