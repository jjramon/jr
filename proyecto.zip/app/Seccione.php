<?php

namespace colegioShaddai;

use Illuminate\Database\Eloquent\Model;

class Seccione extends Model
{
    //
    protected $fillable =  ['nombre','estado'];
}
