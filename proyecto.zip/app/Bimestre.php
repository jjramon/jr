<?php

namespace colegioShaddai;

use Illuminate\Database\Eloquent\Model;

class Bimestre extends Model
{
    //
    protected $fillable =  ['nombre','estado'];
}
