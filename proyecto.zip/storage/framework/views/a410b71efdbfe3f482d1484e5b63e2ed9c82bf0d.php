<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <title>Agregar Usuarios</title>
</head>
<body>
    <div class="container">
        <h1 class="text text-center">Registrar Alumnos</h1>
        <form class="container" role="form" method="POST" ">
          
                <div class="form-row">
                        <div class="form-group col-md-5">
                            <label for="inputIdentificacion">Codigo unido del estudiante:</label>
                            <input type="text" class="form-control" id="inputIdentificacion" placeholder="Ingresar  codigo unico del estudiante" required>
                        </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-5">
                        <label for="inputNombre">Nombres:</label>
                        <input type="text" class="form-control" id="inputApellido" placeholder="Ingresar  nombres del estudiante" required>
                    </div>
                    <div class="form-group col-md-5">
                        <label for="inputApellido">Apellidos:</label>
                        <input type="text" class="form-control" id="inputApellido" placeholder="Ingresar apellidos del estudiante" required>
                    </div>
                </div>
                <div class="form-row">
                        <div class="form-group col-md-5">
                            <label for="inputGenero">Genero del estudiante:</label>
                            <input type="text" class="form-control" id="inputGenero" placeholder="Ingresar  el genero del estudiante" required>
                        </div>
                </div>
                <div class="form-group">
                    <label for="inputDireccion ">Direccion:</label>
                    <input type="text" class="form-control col-md-10" id="inputDireccion" placeholder="Ingresar dirección del estudiante">
                </div>
                <div class="form-group">
                    <label for="inputFechaNacimiento ">Fecha de nacimiento:</label>
                    <input type="date" class="form-control col-md-10" id="inputFechaNacimiento" placeholder="Ingresar fecha de nacimiento del estudiante">
                </div>


                <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>   
</body>
</html>