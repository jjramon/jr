<?php $__env->startSection('contenido'); ?>
    <template v-if="menu==0">
        <main class="main">
                <!-- Breadcrumb -->
        
                <div class="container-fluid texte-center">
                    <div class="card container">
                        <div class="card-header">
                            Bienvenido
                        </div>
                        <div class="card-body">
                            Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex
                            ea commodo consequat.
                        </div>
                    </div>
                </div>
        </main>
    </template>
    <!--mantenimiento-->
        <!---Mantenimiento menu personas -->
            <template v-if="menu==1">
                <genero></genero>
            </template>
            <template v-if="menu==2">
                <tipopersona></tipopersona>       
            </template>
        <!---Mantenimiento menu usuarios -->
            <template v-if="menu==3">
                <rol></rol>
            </template>
            <template v-if="menu==4">
                <h1>asignar vistas</h1>      
            </template>
        <!--Mantenimiento menu materias -->
            <template v-if="menu==5">
                <ciclo></ciclo>
            </template>
            <template v-if="menu==6">
                <dia></dia>
            </template>
            <template v-if="menu==7">
                <horario></horario>
            </template>
            <template v-if="menu==8">
                <bimestre></bimestre>
            </template>
            <template v-if="menu==9">
                <materia></materia>
            </template>
        <!---Mantenimiento menu grados -->
            <template v-if="menu==10">
                <seccion></seccion>
            </template>
            <template v-if="menu==11">
                <nivel></nivel>
            </template>
            <template v-if="menu==23">
                <carrera></carrera>      
            </template>
            <template v-if="menu==12">
                <grado></grado>      
            </template>

        <!---Maenu personas -->
            <template v-if="menu==13">
                <persona></persona>      
            </template>
            <template v-if="menu==14">
                <alumno></alumno> 
            </template>
            <template v-if="menu==15">
            <padrealumno></padrealumno>       
            </template>

        <!---Maenu materias -->
            <template v-if="menu==18">
                <asignardocente></asignardocente>     
            </template>
            <template v-if="menu==19">
                <asignargrado></asignargrado>      
            </template>
            <template v-if="menu==20">
                <asig-notas></asig-notas>     
            </template>

        <!---Maenu pagos -->
            <template v-if="menu==21">
                <h1>Pagos</h1>     
            </template>
            <template v-if="menu==22">
                <h1>Morosos</h1> 
            </template>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>