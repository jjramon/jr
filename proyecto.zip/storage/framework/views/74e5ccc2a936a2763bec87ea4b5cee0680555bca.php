<?php $__env->startSection('contenido'); ?>
    <template v-if="menu==0">
        <example-conponent></example-conponent>
    <template>
    <template v-if="menu==1">
        <h1>Registrar tipo de persona</h1>
    <template>
    <template v-if="menu==2">
        <h1>registrar Personas</h1>
    <template>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>