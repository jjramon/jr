<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Sistema Laravel | Log in</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- css -->

    <link href="css/plantilla.css" rel="stylesheet">

</head>

<body class="app flex-row align-items-center">
  <div class="container">
    <?php echo $__env->yieldContent('login'); ?>
  </div>

  <!-- Bootstrap and necessary plugins -->
  <script src="js/plantilla.js"></script>

</body>
</html>
